class reverse_iter:
    def __init__(self, seq):
        self.seq = seq
    def __getitem__(self, i):
        return self.seq[-(i + 1)]

sequence=['1','2','3']
obj=reverse_iter(sequence)
for x in obj:
    print(x)

