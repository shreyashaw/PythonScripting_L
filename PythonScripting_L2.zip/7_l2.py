class First:
    def method1(self):
        print("First")

class Second(First):
    def method1(self):
        print("Second")

class Third(First):
    def method1(self):
        print("Third")

class Fourth(Second,Third):
    pass
        
obj=Fourth()
obj.method1()