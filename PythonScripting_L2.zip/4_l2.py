import re
str="9hiii8"
x=re.match("^[0-9][\w]*[0-9]$",str)
if x:
    print("starts and ends with digits")
else:
    print("does not starts and ends with digits")
str="hii650world"
x=re.match("[a-zA-Z\s]+$",str)
if x:
    print("contains only white space characters or word characters")
else:
    print("contains other than white space characters or word characters")
str="helloworld"
x=re.findall('\s',str)
if x:
    print("there are white space characters")
else:
    print("there are no whitespace characters")