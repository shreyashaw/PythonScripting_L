import re
f=open("C:\\Users\shrey\.spyder-py3\data.txt","r")
for i in f:
    x=re.match("[\w]+[aeiouAEIOU]{2}[\w]+",i)
    if x:
        print("true")
    else:
        print("False")
