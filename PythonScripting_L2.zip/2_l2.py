try: 
    print("Press Ctrl-C:") 
    ignored = input() 
except KeyboardInterrupt: 
    print("Caught KeyboardInterrupt")
else: 
    print("No exception")
finally:
    print("Done\n")
try:   
    print("give two integers:") 
    a=int(input())
    b=int(input())
    x=a/b
    print(x)   
except ArithmeticError:   
        print("Caught arithmetic exception.")  
else:   
    print("No error")
finally:
    print("Done\n")
def func(): 
    return ans
try:  
    print(func())
except NameError:
    print("Caught NameError")
else:
    print("No error")
finally:
    print("Done\n")
