from calc import fact,find_log10,degree_to_radian,trigo
print(fact(5))
print(find_log10(100))
print(degree_to_radian(360))
print(trigo(60))