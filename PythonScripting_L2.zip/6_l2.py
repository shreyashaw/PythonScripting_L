import math


class sqroot:

    def __init__(self,n1):
        self.n1 = n1

    def squareroot(self):
        print(math.sqrt(self.n1))

class addition:

    def __init__(self,n1,n2):
        self.n1 = n1
        self.n2 = n2

    def add(self):
        print(self.n1+self.n2)


class subtraction:

    def __init__(self,n1,n2):
        self.n1 = n1
        self.n2 = n2

    def sub(self):
        print(self.n1-self.n2)

class multiplication:

    def __init__(self,n1,n2):
        self.n1 = n1
        self.n2 = n2
    
    def product(self):
        print(self.n1*self.n2)

class division:

    def __init__(self,n1,n2):
        self.n1 = n1
        self.n2 = n2

    def div(self):
        print(self.n1/self.n2)

class mathnew(sqroot,addition,subtraction,multiplication,division):
    
    def __init__(self, n1, n2):
        self.n1=n1
        self.n2=n2
        sqroot.__init__(self,n1)
        super().squareroot()
        addition.__init__(self, n1, n2)
        super().add()
        subtraction.__init__(self, n1, n2)
        super().sub()
        multiplication.__init__(self, n1, n2)
        super().product()
        division.__init__(self, n1, n2)
        super().div()

d1 = mathnew(4,2)
