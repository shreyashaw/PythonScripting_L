import time
def decorator(func):
    def inner_func(): 
        print("Before function execution") 
        
        func() 
        
        print("After function execution") 
    return inner_func 

def printing():
    for i in range(10):
        print(i)
    time.sleep(1)
    print("inside called function")
    
printing=decorator(printing)
start_time=time.time()
printing()
print("the function took ",time.time()-start_time," seconds to execute")

