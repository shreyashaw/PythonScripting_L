import math
def fact(n):
    if(n==0 or n==1):
        return 1
    else:
        f=1
        for i in range(1,n+1):
            f=f*i
    return f
def find_log10(n):
    return math.log10(n)
def degree_to_radian(d):
    pi=22/7
    r=d*(pi/180)
    return r
def trigo(x):
    print(math.sin(x))
    print(math.cos(x))
    print(math.tan(x))